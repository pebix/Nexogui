document.addEventListener("DOMContentLoaded", () => {
    console.log("NexoGÜI: Sistema listo.");

    const apiPerfilURL = "php/dashboard.php"; 

    // 1. CONTROL DE SESIÓN Y BIENVENIDA
    async function cargarPerfilUsuario() {
        const userNameElem = document.getElementById("user-name");
        const userRoleElem = document.getElementById("user-role");

        const paginasPublicas = ["loguin.html", "registro.html", "index.html"];
        const paginaActual = window.location.pathname.split("/").pop() || "index.html";

        try {
            const res = await fetch(apiPerfilURL);
            
            if (!res.ok) {
                throw new Error("Error HTTP: " + res.status);
            }

            const datos = await res.json();
            console.log("Respuesta de Sesión:", datos);
            
            if (datos.autenticado) {
                // Muestra el nombre y rol en la pantalla
                if (userNameElem) userNameElem.textContent = datos.usuario.nombre;
                if (userRoleElem) userRoleElem.textContent = datos.usuario.rol;
                
                // Si ya está logueado e intenta ir al login, lo mandamos al dashboard
                if (paginaActual === "loguin.html" || paginaActual === "registro.html") {
                    window.location.href = "dashboard.html";
                }
            } else {
                // Si NO hay sesión y está en una página privada, lo manda al login
                if (!paginasPublicas.includes(paginaActual)) {
                    console.warn("Sin sesión activa. Redirigiendo...");
                    window.location.href = "loguin.html";
                }
            }
        } catch (error) {
            console.error("Error al comprobar la sesión:", error);
            // Si hay un error de conexión en página privada, lo manda al login
            if (!paginasPublicas.includes(paginaActual)) {
                window.location.href = "loguin.html";
            }
        }
    }
    
    cargarPerfilUsuario();

    // 2. INTERACTIVIDAD: BOTONES DE CATEGORÍA EN RÁPIDO (DASHBOARD)
    const quickForm = document.getElementById("quick-report-form");
    if (quickForm) {
        const quickCatButtons = document.querySelectorAll(".btn-cat");
        quickCatButtons.forEach(button => {
            button.addEventListener("click", () => {
                quickCatButtons.forEach(btn => btn.classList.remove("selected"));
                button.classList.add("selected");
            });
        });
    }

    // 3. INTERACTIVIDAD: BOTONES DE CATEGORÍA EN REPORTE COMPLETO
    const fullForm = document.getElementById("full-report-form");
    if (fullForm) {
        const catButtons = document.querySelectorAll(".btn-cat-full");
        catButtons.forEach(btn => {
            btn.addEventListener("click", () => {
                catButtons.forEach(b => b.classList.remove("active"));
                btn.classList.add("active");
            });
        });
    }
});