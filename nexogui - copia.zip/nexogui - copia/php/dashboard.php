<?php
session_start();
header('Content-Type: application/json');

if (isset($_SESSION['nombre'])) {
    echo json_encode([
        'autenticado' => true,
        'usuario' => [
            'nombre' => $_SESSION['nombre'],
            'rol' => $_SESSION['rol']
        ]
    ]);
} else {
    echo json_encode([
        'autenticado' => false,
        'error' => 'No hay sesión iniciada en PHP'
    ]);
}
exit();
?>